import fetch from 'node-fetch';
import { cfg } from './config.js';
import { log } from './util/logger.js';

const rest = (path: string, init: any = {}) => fetch(`${cfg.supabaseUrl}/rest/v1/${path}`, {
  ...init,
  headers: {
    apikey: cfg.supabaseServiceKey || cfg.supabaseAnonKey,
    Authorization: `Bearer ${cfg.supabaseServiceKey || cfg.supabaseAnonKey}`,
    'Content-Type': 'application/json',
    Prefer: 'return=representation',
    ...(init.headers || {})
  }
});

export async function upsertLeads(rows: any[]) {
  if (!rows.length) return [];
  const resp = await rest('leads', { method: 'POST', body: JSON.stringify(rows) });
  if (!resp.ok) {
    log.error('upsertLeads failed', await resp.text());
    throw new Error('upsertLeads failed');
  }
  return await resp.json();
}

export async function listNextEmails(limit: number) {
  // fetch leads with status 'qualified' or 'new' with email present
  const url = `leads?email=not.is.null&status=in.(new,qualified)&order=created_at.asc&limit=${limit}`;
  const resp = await rest(url);
  return await resp.json();
}

export async function markContacted(id: string) {
  const resp = await rest('leads?id=eq.'+id, {
    method: 'PATCH',
    body: JSON.stringify({ status: 'contacted', last_action_at: new Date().toISOString() })
  });
  return await resp.json();
}

export async function insertEmail(row: any) {
  const resp = await rest('emails', { method: 'POST', body: JSON.stringify(row) });
  return await resp.json();
}

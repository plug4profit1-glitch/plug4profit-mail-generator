import fs from 'node:fs';
import path from 'node:path';

export type RawLead = {
  segment: string;          // installateur | gemeente | energie | investeerder
  company_name: string;
  contact_name?: string;
  role?: string;
  email?: string;
  phone?: string;
  website?: string;
  country?: string;
  region?: string;
  notes?: string;
};

export function loadFromSeeds(dataDir = 'data/seeds'): RawLead[] {
  const out: RawLead[] = [];
  const csv = path.join(dataDir, 'leads.csv');
  const json = path.join(dataDir, 'leads.json');
  if (fs.existsSync(csv)) {
    const txt = fs.readFileSync(csv, 'utf-8');
    const [header, ...rows] = txt.split(/\r?\n/).filter(Boolean);
    const cols = header.split(',').map(s => s.trim());
    for (const r of rows) {
      const vals = r.split(',').map(s => s.trim());
      const rec: any = {};
      cols.forEach((c, i) => rec[c] = vals[i] || '');
      out.push(rec as RawLead);
    }
  }
  if (fs.existsSync(json)) {
    const arr = JSON.parse(fs.readFileSync(json, 'utf-8'));
    out.push(...arr);
  }
  return out;
}

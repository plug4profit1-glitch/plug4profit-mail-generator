import 'dotenv/config';

export const cfg = {
  supabaseUrl: process.env.SUPABASE_URL || '',
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '',
  supabaseServiceKey: process.env.SUPABASE_SERVICE_KEY || '',
  schema: process.env.SUPABASE_SCHEMA || 'public',

  veniceKey: process.env.VENICE_API_KEY || process.env.OPENAI_API_KEY || '',
  veniceBase: process.env.VENICE_BASE_URL || process.env.OPENAI_BASE_URL || 'https://api.venice.ai/v1',
  aiModel: process.env.AI_MODEL || 'gpt-4o-mini',

  resendKey: process.env.RESEND_API_KEY || '',
  senderEmail: process.env.SENDER_EMAIL || 'Plug4Profit <no-reply@plug4profit.com>',

  maxEmailsPerRun: Number(process.env.MAX_EMAILS_PER_RUN || 50),
  rateLimitPerMinute: Number(process.env.RATE_LIMIT_PER_MINUTE || 15),
  followupOffsetsDays: (process.env.FOLLOWUP_OFFSETS_DAYS || '3,7').split(',').map(d => Number(d.trim())),
  dryRun: /^true$/i.test(process.env.DRY_RUN || 'false'),
};

import crypto from 'node:crypto';
import { loadFromSeeds, RawLead } from '../ingestion/importer.js';

export type Lead = RawLead & {
  dedupe_key: string;
};

export async function discover(): Promise<Lead[]> {
  // For MVP: load from seeds. Replace with your scraper/API if needed.
  const raws = loadFromSeeds();
  const withKeys = raws.map(r => ({
    ...r,
    dedupe_key: crypto.createHash('sha1').update((r.email || r.website || r.company_name).toLowerCase()).digest('hex')
  }));
  return withKeys;
}

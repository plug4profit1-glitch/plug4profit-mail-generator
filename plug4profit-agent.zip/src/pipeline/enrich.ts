import fetch from 'node-fetch';
import { XMLParser } from 'fast-xml-parser';

export type EnrichedLead = {
  website_title?: string;
  website_desc?: string;
  contact_emails?: string[];
};

export async function enrich(website?: string): Promise<EnrichedLead> {
  if (!website) return {};
  try {
    // Try to fetch homepage quickly and extract <title>
    const resp = await fetch(website, { method: 'GET', redirect: 'follow', timeout: 8000 as any });
    const html = await resp.text();
    const title = (html.match(/<title>(.*?)<\/title>/i) || [,''])[1];
    // naive email extraction
    const emails = Array.from(new Set((html.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || []).map(s => s.toLowerCase())));
    return { website_title: title?.trim(), contact_emails: emails };
  } catch {
    return {};
  }
}

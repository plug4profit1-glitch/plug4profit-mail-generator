import { personalizeEmail } from '../ai/personalize.js';
import { mdToHtml, sendEmail } from '../email/send.js';
import fs from 'node:fs';
import path from 'node:path';

function loadTemplate(segment: string) {
  const map: Record<string,string> = {
    installateur: 'partner_installateur.md',
    gemeente: 'gemeente.md',
    investeerder: 'investeerder.md'
  };
  const file = map[segment] || 'partner_installateur.md';
  const p = path.join('src','email','templates', file);
  const raw = fs.readFileSync(p, 'utf-8');
  const subj = (raw.match(/^Subject:\s*(.*)$/m) || [,''])[1].trim();
  const body = (raw.match(/^Body:\s*\n([\s\S]*)$/m) || [,''])[1].trim();
  return { baseSubject: subj, baseBody: body };
}

export async function composeAndSend(opts: {
  segment: string,
  company_name: string,
  contact_name?: string,
  email?: string,
  website?: string,
  region?: string
}) {
  if (!opts.email) return { skipped: true, reason: 'no-email' };

  const { baseSubject, baseBody } = loadTemplate(opts.segment);
  const filled = baseBody
    .replace(/{{name}}/g, opts.contact_name || 'relatie')
    .replace(/{{region}}/g, opts.region || 'jouw regio');

  const { subject, body } = await personalizeEmail({
    segment: opts.segment,
    company: opts.company_name,
    contact: opts.contact_name,
    website: opts.website,
    baseSubject,
    baseBody: filled
  });

  const html = mdToHtml(body);
  const res = await sendEmail(opts.email, subject, html);
  return { sent: true, provider: 'resend', id: res.id };
}

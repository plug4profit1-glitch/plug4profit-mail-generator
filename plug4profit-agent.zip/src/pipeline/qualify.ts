import { scoreLead } from '../ai/scorer.js';

export async function qualify(input: {
  company_name: string,
  segment: string,
  website?: string,
  notes?: string
}) {
  return await scoreLead({
    company: input.company_name,
    segment: input.segment,
    website: input.website,
    notes: input.notes
  });
}

import { addDays } from 'date-fns';

export function computeFollowups(base: Date, offsetsDays: number[]) {
  return offsetsDays.map(d => addDays(base, d));
}

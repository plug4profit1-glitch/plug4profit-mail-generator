import { chat } from './venice.js';

export async function personalizeEmail(input: {
  segment: string,
  company: string,
  contact?: string,
  website?: string,
  baseSubject: string,
  baseBody: string
}) {
  const sys = 'Je bent een outreach-copywriter. Houd het kort, zakelijk, Nederlands, met duidelijke call-to-action. Voeg opt-out toe.';
  const user = `Schrijf onderwerp + e-mailtekst op basis van dit template. Vul details aan met subtiele personalisatie (1 zin).
Segment: ${input.segment}
Company: ${input.company}
Contact: ${input.contact || '-'}
Website: ${input.website || '-'}

Template:
SUBJECT: ${input.baseSubject}
BODY:\n${input.baseBody}

Geef JSON:
{"subject": "...", "body": "..."}`;

  const res = await chat([
    { role: 'system', content: sys },
    { role: 'user', content: user }
  ], 0.4);

  try {
    const parsed = JSON.parse(res);
    return parsed;
  } catch {
    return { subject: input.baseSubject, body: input.baseBody };
  }
}

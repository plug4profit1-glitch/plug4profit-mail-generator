import fetch from 'node-fetch';
import { cfg } from '../config.js';
import { log } from '../util/logger.js';

type ChatMsg = { role: 'system'|'user'|'assistant'; content: string };

export async function chat(messages: ChatMsg[], temperature = 0.3): Promise<string> {
  const url = `${cfg.veniceBase}/chat/completions`;
  const body = {
    model: cfg.aiModel,
    temperature,
    messages
  };
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${cfg.veniceKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (!resp.ok) {
    const text = await resp.text();
    log.error('AI error', resp.status, text);
    throw new Error(`AI HTTP ${resp.status}`);
  }
  const data: any = await resp.json();
  // OpenAI-compatible shape
  const out = data?.choices?.[0]?.message?.content || '';
  return String(out).trim();
}

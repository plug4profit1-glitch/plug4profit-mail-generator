import { chat } from './venice.js';

export async function scoreLead(input: {
  company: string,
  segment: string,
  website?: string,
  notes?: string
}) {
  const prompt = `Geef een score 0..1 voor kans op samenwerking met Plug4Profit (monetizing EV-laadpalen).
Segment: ${input.segment}
Bedrijf: ${input.company}
Website: ${input.website || '-'}
Notes: ${input.notes || '-'}
Return JSON: {"score": number, "label": "qualified|unqualified|unclear", "why": string}`;
  const res = await chat([
    { role: 'system', content: 'Je bent een B2B lead-kwalificatiemodel. Antwoord alleen met JSON.' },
    { role: 'user', content: prompt }
  ], 0.2);

  try {
    const parsed = JSON.parse(res);
    return parsed;
  } catch {
    return { score: 0.3, label: 'unclear', why: 'parse-fallback' };
  }
}

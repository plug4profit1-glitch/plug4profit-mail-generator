import { log } from './util/logger.js';
import { cfg } from './config.js';
import { discover } from './pipeline/discover.js';
import { enrich } from './pipeline/enrich.js';
import { qualify } from './pipeline/qualify.js';
import { composeAndSend } from './pipeline/outreach.js';
import { upsertLeads, listNextEmails, markContacted, insertEmail } from './db.js';
import { rateLimit } from './util/rateLimit.js';

async function runDiscoverQualify() {
  log.info('Discovering raw leads (seeds)...');
  const leads = await discover();

  log.info('Enrich + Qualify...');
  const enriched = await Promise.all(leads.map(async (l) => {
    const more = await enrich(l.website);
    const q = await qualify({ company_name: l.company_name, segment: l.segment, website: l.website, notes: l.notes });
    return {
      ...l,
      email: l.email || more.contact_emails?.[0] || null,
      score: q.score,
      status: q.label === 'qualified' && (q.score ?? 0) >= 0.5 ? 'qualified' : 'new',
      notes: [l.notes || '', more.website_title ? `title:${more.website_title}` : '', q.why ? `why:${q.why}` : ''].filter(Boolean).join(' \n ')
    };
  }));

  const up = await upsertLeads(enriched.map(e => ({
    source: 'seeds',
    segment: e.segment,
    company_name: e.company_name,
    contact_name: e.contact_name,
    role: e.role,
    email: e.email,
    phone: e.phone,
    website: e.website,
    country: e.country,
    region: e.region,
    notes: e.notes,
    score: e.score,
    status: e.status,
    dedupe_key: e.dedupe_key
  })));

  log.info('Upserted leads:', up.length);
}

async function runOutreach() {
  const todo = await listNextEmails(cfg.maxEmailsPerRun);
  log.info('Outreach candidates:', todo.length);

  await rateLimit(cfg.rateLimitPerMinute, todo.map((lead: any) => async () => {
    const res = await composeAndSend({
      segment: lead.segment,
      company_name: lead.company_name,
      contact_name: lead.contact_name,
      email: lead.email,
      website: lead.website,
      region: lead.region
    });

    if (res?.sent) {
      await markContacted(lead.id);
      await insertEmail({
        lead_id: lead.id,
        subject: 'initial',   // actual subject logged within provider meta
        body: 'see provider',
        provider: 'resend',
        provider_message_id: res.id,
        status: 'sent'
      });
      log.info('Sent to', lead.email, res.id);
    } else {
      log.warn('Skipped', lead.company_name, res?.reason);
    }
  }));
}

async function main() {
  log.info('=== Plug4Profit Agent Run ===');
  await runDiscoverQualify();
  await runOutreach();
  log.info('=== Done ===');
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});

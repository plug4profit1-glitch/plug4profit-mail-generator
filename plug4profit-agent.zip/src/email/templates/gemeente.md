Subject: Pilot buur-laadnetwerk: minder netdruk, meer toegang
Body:
Beste {{name}},

Plug4Profit helpt inwoners met privé-laadpassen hun **overtollige capaciteit** te delen met buurtgenoten. Dat **verlicht piekbelasting** en vergroot de laadtoegang zonder extra openbare palen.

We zoeken gemeenten voor een **pilot** (participatie, datadeling, sociale tarieven). Resultaat: inzicht in benutting, CO2-besparing en wijkbereik.

Kunnen we dit kort verkennen?
— Delano Bennett, CEO Plug4Profit

PS: Afmelden? Reageer met ‘uitschrijven’.

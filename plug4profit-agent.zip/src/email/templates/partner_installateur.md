Subject: Samenwerken? Extra verdiensten voor uw laadpalen-klanten
Body: 
Beste {{name}},

Wij bouwen met Plug4Profit een platform waarmee particuliere laadpalen **extra inkomsten** genereren door slim delen binnen de buurt. 
Uw klanten (installaties) krijgen: hogere benutting, vergoeding per kWh, en beheer via app.

Zin om **partner** te worden (pilot in {{region}})? We leveren onboarding, tariefadvies en support; uw bedrijf ontvangt partner-fee per actieve aansluiting.

Spreken komende week 20 min? 
— Delano Bennett, CEO Plug4Profit

PS: Afmelden voor e-mails? Reageer met ‘uitschrijven’.

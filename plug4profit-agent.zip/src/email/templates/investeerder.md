Subject: Dealflow: P2P EV-charging met inkomsten voor huishoudens
Body:
Beste {{name}},

Plug4Profit monetiseert particuliere EV-laadpalen via **gedeelde toegang** met verificatie & tariefsturing. Tractie: [vul hier KPI’s].

We ronden een pre-seed van €150k voor MVP + pilots (gemeenten en installateurs). Interesse in een 15-min kennismaking?

— Delano Bennett, CEO Plug4Profit

PS: Afmelden? Reageer met ‘uitschrijven’.

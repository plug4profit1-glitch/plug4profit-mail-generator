import fetch from 'node-fetch';
import { cfg } from '../config.js';
import { log } from '../util/logger.js';

export async function sendEmail(to: string, subject: string, html: string) {
  if (cfg.dryRun) {
    log.info('[DRY_RUN] Email not sent:', to, subject);
    return { id: 'dry_run' };
  }
  const resp = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${cfg.resendKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: cfg.senderEmail,
      to,
      subject,
      html
    })
  });
  const data: any = await resp.json();
  if (!resp.ok) {
    log.error('Resend error', resp.status, data);
    throw new Error('Resend failed');
  }
  return data; // { id: '...' }
}

export function mdToHtml(md: string) {
  // ultra-light markdown -> html (headers/links/linebreaks)
  const esc = (s: string) => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  let html = esc(md);
  html = html.replace(/^# (.*)$/gm, '<h1>$1</h1>');
  html = html.replace(/^## (.*)$/gm, '<h2>$1</h2>');
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\n/g, '<br/>');
  return `<div style="font-family:Inter,Arial,sans-serif;font-size:14px;line-height:1.5">${html}</div>`;
}

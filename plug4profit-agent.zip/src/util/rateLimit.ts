export async function rateLimit<T>(opsPerMinute: number, tasks: (() => Promise<T>)[]) {
  const interval = Math.max(60000 / Math.max(1, opsPerMinute), 1);
  const results: T[] = [];
  for (let i = 0; i < tasks.length; i++) {
    const res = await tasks[i]();
    results.push(res);
    if (i < tasks.length - 1) await new Promise(r => setTimeout(r, interval));
  }
  return results;
}

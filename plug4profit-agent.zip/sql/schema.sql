-- Basic schema for leads/outreach
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  updated_at timestamptz,
  source text,               -- e.g. 'csv','manual','api'
  segment text,              -- 'installateur','gemeente','energie','investeerder'
  company_name text,
  contact_name text,
  role text,
  email text,
  phone text,
  website text,
  country text,
  region text,
  notes text,
  score numeric,             -- AI score 0..1
  status text default 'new', -- 'new','qualified','contacted','responded','won','lost','nurture'
  last_action_at timestamptz,
  next_action_at timestamptz,
  dedupe_key text unique
);

create table if not exists emails (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  lead_id uuid references leads(id) on delete cascade,
  direction text default 'out', -- 'out'|'in'
  subject text,
  body text,
  provider text default 'resend',
  provider_message_id text,
  status text default 'queued', -- 'queued','sent','bounced','opened','replied','failed'
  meta jsonb
);

create table if not exists outreach_runs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  processed integer default 0,
  sent integer default 0,
  errors integer default 0,
  meta jsonb
);

create index if not exists leads_email_idx on leads(email);
create index if not exists leads_status_idx on leads(status);
create index if not exists emails_lead_idx on emails(lead_id);

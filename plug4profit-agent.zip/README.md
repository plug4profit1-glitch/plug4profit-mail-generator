# Plug4Profit Autonomous Lead & Outreach Agent

Deze repo bevat een **kant-en-klare agent** die:
1) leads inlaadt/verrijkt,
2) AI-kwalificatie uitvoert,
3) gepersonaliseerde e-mails verstuurt met **Resend**,
4) opvolg-cadence beheert,
5) resultaten logt in **Supabase**.

> **Belangrijk (AVG/GDPR)**: gebruik uitsluitend B2B-contacts, voeg altijd opt-out toe, en respecteer robots.txt wanneer je externe sites crawlt. 
> Configureer SPF, DKIM en DMARC voor je verzenddomein om deliverability te verbeteren.

## Snelstart

```bash
# Node 18+ aanbevolen
cp .env.example .env
# zet je variabelen in .env

npm install
npm run dev   # voor lokale run (hot)
# of
npm run build && npm start
```

## Wat doet het?

- `src/pipeline/discover.ts` leest ruwe leads uit CSV/JSON of van een API (placeholder).
- `src/pipeline/enrich.ts` haalt basis website-info op en zoekt contactgegevens (voorzichtig en respectvol).
- `src/pipeline/qualify.ts` gebruikt Venice/OpenAI-compatibele API om te labelen en te scoren.
- `src/pipeline/outreach.ts` personaliseert e-mails met AI + templates en verstuurt via **Resend**.
- `src/pipeline/schedule.ts` plant follow-ups (bijv. na 3 en 7 dagen).
- `src/index.ts` orkestreert één run; kan via CRON/PM2 herhaald draaien.

## Deploy

- **Docker**: zie `Dockerfile`. 
- **Render/Fly/Heroku**: gebruik `Procfile` met `worker: node dist/index.js`.
- **CRON**: plan `npm run start` elke X minuten.

## Supabase

Voer de schema’s in `sql/schema.sql` uit (SQL editor of CLI). Gebruik de **Service Key** in `.env` voor server-side operaties.

## Ingestiebronnen

Plaats CSV in `data/seeds/leads.csv` of JSON in `data/seeds/leads.json`. Je kunt ook een eigen scraper/API koppelen in `src/ingestion/importer.ts`. 

## Belangrijke variabelen

- `MAX_EMAILS_PER_RUN`: safety cap per run.
- `RATE_LIMIT_PER_MINUTE`: om spamflags te voorkomen.
- `DRY_RUN=true`: test zonder daadwerkelijk mails te verzenden.

## Juridisch

- B2B cold outreach is toegestaan mits **legitiem belang**, **relevantie** en **opt‑out**.
- Gebruik de meegeleverde e-mailtemplates met opt-out.

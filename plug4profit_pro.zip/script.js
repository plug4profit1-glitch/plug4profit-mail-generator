// Dynamic page rendering for Plug4Profit Pro

document.addEventListener('DOMContentLoaded', () => {
  const pages = {
    dashboard: renderDashboard,
    leadDiscovery: renderLeadDiscovery,
    leadManagement: renderLeadManagement,
    campaignCreator: renderCampaignCreator,
    emailTracking: renderEmailTracking,
    analytics: renderAnalytics,
  };
  const navItems = document.querySelectorAll('nav li');
  navItems.forEach((item) => {
    item.addEventListener('click', () => {
      navItems.forEach((i) => i.classList.remove('active'));
      item.classList.add('active');
      const page = item.getAttribute('data-page');
      const title = item.querySelector('span').textContent;
      document.getElementById('pageTitle').textContent = title;
      if (pages[page]) {
        pages[page]();
      }
    });
  });
  // initial load
  renderDashboard();
});

function navigateTo(page) {
  const navItems = document.querySelectorAll('nav li');
  navItems.forEach((item) => {
    if (item.getAttribute('data-page') === page) {
      item.classList.add('active');
      document.getElementById('pageTitle').textContent = item.querySelector('span').textContent;
    } else {
      item.classList.remove('active');
    }
  });
  switch (page) {
    case 'dashboard':
      renderDashboard();
      break;
    case 'leadDiscovery':
      renderLeadDiscovery();
      break;
    case 'leadManagement':
      renderLeadManagement();
      break;
    case 'campaignCreator':
      renderCampaignCreator();
      break;
    case 'emailTracking':
      renderEmailTracking();
      break;
    case 'analytics':
      renderAnalytics();
      break;
    default:
      renderDashboard();
  }
}

// Dashboard page
function renderDashboard() {
  const content = document.getElementById('contentArea');
  content.innerHTML = '';
  // placeholder numbers; replace with API calls if desired
  const totalLeads = 293;
  const activeCampaigns = 4;
  const totalEmails = 129;
  const openRate = 0;
  const cards = document.createElement('div');
  cards.className = 'card-container';
  cards.innerHTML = `
    <div class="card">
      <div class="card-title">Totaal Leads</div>
      <div class="card-value">${totalLeads}</div>
      <div class="card-description">Beschikbare contacten</div>
      <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10.011 10.011 0 0 0 12 2zm0 18a8 8 0 1 1 8-8a8.009 8.009 0 0 1-8 8z"/><path d="M13 7h-2v6h6v-2h-4z"/></svg>
    </div>
    <div class="card">
      <div class="card-title">Actieve Campagnes</div>
      <div class="card-value">${activeCampaigns}</div>
      <div class="card-description">Lopende email campagnes</div>
      <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M6 2h12a2 2 0 0 1 2 2v14l-4-4H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z"/></svg>
    </div>
    <div class="card">
      <div class="card-title">Verzonden Emails</div>
      <div class="card-value">${totalEmails}</div>
      <div class="card-description">Totaal verstuurde mails</div>
      <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 4H2v16h20z" fill="none"/><path d="M22 4H2v16h20zm-2 4l-8 5l-8-5"/></svg>
    </div>
    <div class="card">
      <div class="card-title">Open Rate</div>
      <div class="card-value">${openRate}%</div>
      <div class="card-description">Email open percentage</div>
      <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21.54 15.34A10 10 0 1 0 18.66 18.2l-1.42-1.42a8 8 0 1 1 2.83-2.83z"/><path d="M12 8v4l3 3"/></svg>
    </div>
  `;
  content.appendChild(cards);
  // Quick actions
  const actions = document.createElement('div');
  actions.className = 'quick-actions';
  actions.innerHTML = `
    <button onclick="navigateTo('campaignCreator')">+ Nieuwe Campagne Starten</button>
    <button onclick="navigateTo('leadManagement')">Leads Beheren</button>
    <button onclick="navigateTo('analytics')">Email Performance</button>
  `;
  content.appendChild(actions);
  // About section
  const about = document.createElement('div');
  about.className = 'section';
  about.innerHTML = `
    <h2>Over Plug4Profit</h2>
    <p><strong>EV‑laadoplossingen voor hotels en installateurs</strong></p>
    <p>Onze missie: Hotels helpen extra inkomsten genereren via slimme laadinfrastructuur terwijl we de transitie naar elektrisch vervoer ondersteunen.</p>
    <p><strong>Website:</strong> <a href="https://plug4profit1.online" target="_blank">plug4profit1.online</a></p>
    <p><strong>Contact:</strong> <a href="mailto:info@plug4profit1.online">info@plug4profit1.online</a></p>
  `;
  content.appendChild(about);
}

// Lead Discovery page
function renderLeadDiscovery() {
  const content = document.getElementById('contentArea');
  content.innerHTML = `
    <div class="section">
      <h2>Lead Discovery</h2>
      <p>Gebruik trefwoorden om nieuwe potentiële leads te vinden. Deze functie is een toekomstige uitbreiding.</p>
      <div class="form-group">
        <label for="discoveryKeywords">Trefwoorden:</label>
        <input type="text" id="discoveryKeywords" placeholder="bijv. duurzaam, hotel, laadpaal" />
      </div>
      <button class="primary" onclick="alert('Lead Discovery is binnenkort beschikbaar!')">Zoek Leads</button>
    </div>
  `;
}

// Global leads array (in-memory) for demonstration
let leads = [];

// Load leads into the table
function loadLeads() {
  const tbody = document.querySelector('#leadsTable tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  leads.forEach((lead) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${lead.name}</td><td>${lead.email}</td><td>${lead.category}</td>`;
    tbody.appendChild(tr);
  });
}

// Add a new lead from the form
function addLead() {
  const nameInput = document.getElementById('leadName');
  const emailInput = document.getElementById('leadEmail');
  const categorySelect = document.getElementById('leadCategory');
  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const category = categorySelect.value;
  if (!name || !email) {
    alert('Voer alstublieft naam en email in.');
    return;
  }
  leads.push({ name: name, email: email, category: category });
  loadLeads();
  nameInput.value = '';
  emailInput.value = '';
}

// Lead Management page
function renderLeadManagement() {
  const content = document.getElementById('contentArea');
  content.innerHTML = '';
  const section = document.createElement('div');
  section.className = 'section';
  section.innerHTML = `
    <h2>Lead Management</h2>
    <p>Beheer uw bestaande leads of voeg nieuwe leads toe.</p>
    <div class="form-group">
      <label for="leadName">Naam</label>
      <input type="text" id="leadName" />
    </div>
    <div class="form-group">
      <label for="leadEmail">Email</label>
      <input type="email" id="leadEmail" />
    </div>
    <div class="form-group">
      <label for="leadCategory">Categorie</label>
      <select id="leadCategory">
        <option value="hotel">Hotel</option>
        <option value="installateur">Installateur</option>
      </select>
    </div>
    <button class="primary" onclick="addLead()">Lead Toevoegen</button>
    <div class="section" id="leadsList" style="margin-top:24px;">
      <h3>Bestaande Leads</h3>
      <div class="table-responsive">
        <table id="leadsTable">
          <thead><tr><th>Naam</th><th>Email</th><th>Categorie</th></tr></thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
  `;
  content.appendChild(section);
  loadLeads();
}

// Campaign Creator page
function renderCampaignCreator() {
  const content = document.getElementById('contentArea');
  content.innerHTML = `
    <div class="section">
      <h2>Campaign Creator</h2>
      <p>Gebruik onze AI voor het genereren van gepersonaliseerde email pitches.</p>
      <div class="form-group">
        <label for="campaignName">Campagne Naam</label>
        <input type="text" id="campaignName" />
      </div>
      <div class="form-group">
        <label for="campaignKeywords">Trefwoorden</label>
        <input type="text" id="campaignKeywords" placeholder="bijv. groen, duurzaam, luxe hotel" />
      </div>
      <div class="form-group">
        <label for="campaignTemplate">Email Template</label>
        <textarea id="campaignTemplate" rows="6" placeholder="Uw email template, gebruik [Naam] om te personaliseren"></textarea>
      </div>
      <button class="primary" onclick="generateContent()">Genereer Email</button>
      <div id="generatedContent" class="section" style="display:none; margin-top:16px;">
        <h3>Gegenereerde Email</h3>
        <div id="emailPreview" style="white-space: pre-wrap;"></div>
        <button class="primary" style="margin-top:12px;" onclick="sendCampaign()">Campagne Versturen</button>
      </div>
    </div>
  `;
}

// Generate email content (placeholder implementation)
function generateContent() {
  const keywords = document.getElementById('campaignKeywords').value.trim();
  const template = document.getElementById('campaignTemplate').value.trim();
  if (!keywords || !template) {
    alert('Vul trefwoorden en template in.');
    return;
  }
  // In a real implementation this would call your AI edge function.
  // For the placeholder we simply replace [Naam] with a dummy name.
  const preview = template.replace(/\[Naam\]/g, 'Jan Jansen');
  const previewDiv = document.getElementById('emailPreview');
  previewDiv.textContent = preview;
  const container = document.getElementById('generatedContent');
  container.style.display = 'block';
}

// Send campaign (placeholder)
function sendCampaign() {
  alert('Campagne verzonden! (placeholder)');
  // In a real implementation you would call your API to send emails here.
}

// Email Tracking page
function renderEmailTracking() {
  const content = document.getElementById('contentArea');
  content.innerHTML = `
    <div class="section">
      <h2>Email Tracking</h2>
      <p>Bekijk de status van verzonden campagnes.</p>
      <div class="table-responsive">
        <table>
          <thead><tr><th>Campagne</th><th>Lead</th><th>Status</th><th>Datum</th></tr></thead>
          <tbody id="trackingBody">
            <tr><td>Najaarscampagne</td><td>Jan Jansen</td><td>Bezorgd</td><td>22‑08‑2025</td></tr>
            <tr><td>Najaarscampagne</td><td>Piet Pieters</td><td>Gelezen</td><td>23‑08‑2025</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// Analytics page
function renderAnalytics() {
  const content = document.getElementById('contentArea');
  content.innerHTML = `
    <div class="section">
      <h2>Analytics</h2>
      <p>Inzichten in uw campagnes en leads.</p>
      <div class="card-container">
        <div class="card">
          <div class="card-title">Gemiddelde Open Rate</div>
          <div class="card-value">35%</div>
          <div class="card-description">Gemiddeld over alle campagnes</div>
        </div>
        <div class="card">
          <div class="card-title">Top Categorie</div>
          <div class="card-value">Hotels</div>
          <div class="card-description">Categorie met meeste respons</div>
        </div>
        <div class="card">
          <div class="card-title">Beste Campagne</div>
          <div class="card-value">Lente Promo</div>
          <div class="card-description">Hoogste click‑through rate</div>
        </div>
      </div>
      <div class="section" style="margin-top:24px;">
        <h3>Trend Overzicht</h3>
        <p>Grafieken en statistieken komen hier in toekomstige versies.</p>
      </div>
    </div>
  `;
}
Plug4Profit Pro Mail Generator
=================================

This is a self‑contained static web application that implements an improved version of the Plug4Profit mail generator dashboard.  The design draws inspiration from the original application but adds additional pages such as Lead Discovery and Analytics, modernises the layout and uses a consistent golden/brown colour theme.  All pages live in a single HTML document and are swapped dynamically using vanilla JavaScript.

> **Note:** This app does not include a connection to Supabase or any other backend out of the box.  Placeholder data is used throughout to illustrate how the interface should look and feel.  To connect your own backend you should edit `script.js` and replace the placeholder functions with calls to your API.

### Running the app

1.  Copy the contents of this folder to a web server or open `index.html` directly in a modern browser.
2.  The sidebar allows you to switch between Dashboard, Lead Discovery, Lead Management, Campaign Creator, Email Tracking and Analytics pages.
3.  To hook up real data you can modify the JavaScript functions in `script.js`.

### Customisation

*  Replace `images/logo.png` with your company logo.  The provided `logo.png` is a simple abstract plug/bolt icon generated via AI.
*  Adjust the colour palette in `styles.css` by editing the CSS custom properties under `:root`.
